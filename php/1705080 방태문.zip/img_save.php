<?php

$i=0;

$dir = "stud";

$dir2 = "stud2";



if ($dh = opendir($dir)) {

 while (($file = readdir($dh)) != false) {

  if ($file != "." && $file != ".." && substr($file,0,1) != ".") {

   if (filetype($dir ."/". $file) == "file") {

    $arr[$i] = $file;

    $i++;

    $target = $dir ."/". $file;

    $target2 = $dir2 ."/". $file;



    $size = getimagesize($target);

    $width = $size[0];

    $height = $size[1];

    $type = $size[2];

    $attr = $size[3];



    $idno = substr($file, 0, strrpos($file, '.'));

    echo "$i: [$idno] $file ($type, $attr)\n";



    if($width>200) {

     $new_width = 200;

     $new_height = $height * (200/$width);



     $image_p = imagecreatetruecolor($new_width, $new_height);

     $image = imagecreatefromjpeg($target);

     imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

     imagejpeg($image_p, "$target2", 100);

     imagedestroy($image);

     imagedestroy($image_p);

    } else {

     $new_width = $width;

     $new_height = $height;



     $image_p = imagecreatetruecolor($new_width, $new_height);

     $image = imagecreatefromjpeg($target);

     imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

     imagejpeg($image_p, "$target2", 100);

     imagedestroy($image);

     imagedestroy($image_p);

    }



    $size = getimagesize($target2);

    $width = $size[0];

    $height = $size[1];



    $imageblob = addslashes(fread(fopen($target2, "r"), filesize($target2)));

    $filesize = filesize($target2) ;



    $sql = "select count(*) as cnt from photo where idno='$idno'";

    $row = dbqueryfetch($sql);

    if($row[0]<1) {

     $sql = "insert into photo set `idno`='$idno', `image`='$imageblob', `width`='$width', `height`='$height', `filesize`='$filesize', `insdt`=now()";

     dbquery($sql) or die(mysql_error());

    }

   }

  }

 }

 closedir($dh);

}



?>
