<?php
  $composer=$_REQUEST["composer"];
  $con = mysqli_connect("localhost", "root", "", "project");
	$sql = "update survey set $composer = $composer + 1";

	mysqli_query($con, $sql);
  mysqli_close($con); //DB 연결 끊기

	echo "
	   <script>
	    location.href = './result.php';
	   </script>
	";
?>
