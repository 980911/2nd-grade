-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- 생성 시간: 21-12-14 09:11
-- 서버 버전: 10.4.21-MariaDB
-- PHP 버전: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `project`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `board`
--

CREATE TABLE `board` (
  `num` int(11) NOT NULL,
  `id` char(15) NOT NULL,
  `name` char(10) NOT NULL,
  `subject` char(200) NOT NULL,
  `content` text NOT NULL,
  `regist_day` char(20) NOT NULL,
  `hit` int(11) NOT NULL,
  `file_name` char(40) DEFAULT NULL,
  `file_type` char(40) DEFAULT NULL,
  `file_copied` char(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `board`
--

INSERT INTO `board` (`num`, `id`, `name`, `subject`, `content`, `regist_day`, `hit`, `file_name`, `file_type`, `file_copied`) VALUES
(0, 'abca', 'xoans', 'ㅇㅇ', 'ㅇㅇ', '2021-12-06 (15:19)', 5, '', '', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `board2`
--

CREATE TABLE `board2` (
  `idx` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `pw` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date` date NOT NULL,
  `hit` int(11) NOT NULL,
  `lock_post` int(11) NOT NULL,
  `thumbup` int(11) NOT NULL,
  `file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `board2`
--

INSERT INTO `board2` (`idx`, `name`, `pw`, `title`, `content`, `date`, `hit`, `lock_post`, `thumbup`, `file`) VALUES
(4, 'num1', '$2y$10$d62rsMdF/rcqXnKlRRCkCOXFVdUwfEmJumzg0vTFSaqrVxAudnHpe', 'test', 'secret', '2021-12-11', 4, 0, 0, ''),
(5, 'abc', '$2y$10$O9Yy49LGzL/xpKajy/50ge2OTl3fe11y0lmAQUcUTKTUWjRSTC.Le', 'aaa', 'gg', '2021-12-11', 4, 0, 0, ''),
(8, 'ㅇㅇ', '$2y$10$PhP3cNzAyrPfJN9ApwW9AOWzQzBqZwyhrWZVUHsPZGR2hV/CwD7nG', 'ㅇㅇ', 'ㅇㅇ', '2021-12-13', 0, 0, 0, ''),
(9, 'ㅇㅇ', '$2y$10$BeEV01bieZ0UiYjaLDUvOORohQ7Mh1XDB1m6VvhTghXD6EaEeedGy', 'ㅇㅇ', 'ㅇㅇ', '2021-12-13', 0, 0, 0, ''),
(10, 'ㅇㅇ', '$2y$10$.5c1/A21QM75G3KRRr3xtuU59DRde0UoNMgq8/oKBHluw1JdNDUk2', 'ㅇㅇ', 'ㅇㅇ', '2021-12-13', 1, 0, 0, ''),
(14, 'aaa', '$2y$10$MEoSo6aAxasUN/IRl48i7OS3nCkCQTBrKk7sWpSp1Qfx5Q0Wtqb0O', '안녕하세요', '안녕하세요', '2021-12-13', 2, 0, 1, '');

-- --------------------------------------------------------

--
-- 테이블 구조 `cre_board`
--

CREATE TABLE `cre_board` (
  `idx` int(11) NOT NULL,
  `board_name` varchar(200) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `greet`
--

CREATE TABLE `greet` (
  `num` int(11) NOT NULL,
  `id` varchar(15) NOT NULL,
  `name` varchar(10) NOT NULL,
  `nick` varchar(10) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `regist_day` char(20) DEFAULT NULL,
  `hit` int(11) DEFAULT NULL,
  `is_html` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `members`
--

CREATE TABLE `members` (
  `num` int(11) NOT NULL,
  `id` char(15) NOT NULL,
  `pass` char(15) NOT NULL,
  `name` char(10) NOT NULL,
  `email` char(80) DEFAULT NULL,
  `regist_day` char(20) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `point` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `members`
--

INSERT INTO `members` (`num`, `id`, `pass`, `name`, `email`, `regist_day`, `level`, `point`) VALUES
(1, 'abca', '1234', 'xoans', 'ba0808@naver.com', '2021-12-06 (10:05)', 9, 100),
(2, 'admin', '12345', '관리자', 'admin@naver.com', '2021-12-11 (13:52)', 1, 0),
(3, 'abcd', '1234', 'qqq', 'aaaaaaaaa@naver.com', '2021-12-14 (08:30)', 9, 0),
(4, 'bbbb', '1234', 'ggggg', 'ba0808@naver.comdd', '2021-12-14 (08:32)', 9, 0),
(5, 'hhhh', '1234', 'abcde', 'aaaaaaaaa@naver.comddbb', '2021-12-14 (08:34)', 9, 0),
(6, 'qkd', '1234', 'xoans', 'ba0808@naver.coma', '2021-12-14 (08:42)', 9, 0);

-- --------------------------------------------------------

--
-- 테이블 구조 `memo`
--

CREATE TABLE `memo` (
  `num` int(11) NOT NULL,
  `id` varchar(15) NOT NULL,
  `name` varchar(10) NOT NULL,
  `nick` varchar(10) NOT NULL,
  `content` text NOT NULL,
  `regist_day` char(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `memo`
--

INSERT INTO `memo` (`num`, `id`, `name`, `nick`, `content`, `regist_day`) VALUES
(16, 'abca', '', '', 'ㅇ', '2021-12-06 22:43:06'),
(32, '', '', '', 'ddd', '2021-12-07 14:22:34'),
(51, '', '', '', 'ddd', '2021-12-13 20:24:45'),
(52, '', '', '', 'ㅋㅋㅋ', '2021-12-14 16:16:16'),
(53, '', '', '', '메모', '2021-12-14 17:00:17');

-- --------------------------------------------------------

--
-- 테이블 구조 `memo_ripple`
--

CREATE TABLE `memo_ripple` (
  `num` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `id` varchar(15) NOT NULL,
  `name` varchar(10) NOT NULL,
  `nick` varchar(10) NOT NULL,
  `content` text NOT NULL,
  `regist_day` char(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `reply`
--

CREATE TABLE `reply` (
  `idx` int(11) NOT NULL,
  `con_num` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `pw` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `reply`
--

INSERT INTO `reply` (`idx`, `con_num`, `name`, `pw`, `content`, `date`) VALUES
(3, 6, 'abcd', '$2y$10$4Hm6G/BfYkkK0bRV.bJ3Wu2RGUw16xcYQqyNkWOBx4d0ldSWdWThO', 'test', '2021-12-11 21:11:14'),
(6, 6, 'hhhh', '$2y$10$Vxy3AsU5q2ZnMfJ2BF6CSeYEIaWnH8j/hEkXthYYSxjNwuWU3D/0u', '안녕하세요', '2021-12-14 16:41:52'),
(7, 14, 'abcd', '$2y$10$9xRdrcpS5ir/qJS6ocrtQOhY59Do9h3g1hw9nso7jUvK.OtcW9Lnq', '안녕하세요', '2021-12-14 16:50:46'),
(8, 14, 'aaaa', '$2y$10$tYLp7czMIgUE4dYdmNbnhOahrPmHw6eSimDtpeHqpMLdzwln.AFTS', '테스트', '2021-12-14 16:59:01'),
(9, 10, 'abca', '$2y$10$ShSjjPa6ODE0g0gz7ShhUOeWnZxjJg59uz4NCrXCP6gLY8QkHgi2m', 'aaaa', '2021-12-14 17:10:14');

-- --------------------------------------------------------

--
-- 테이블 구조 `write_form`
--

CREATE TABLE `write_form` (
  `idx` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `pw` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date` date NOT NULL,
  `hit` int(11) NOT NULL,
  `lock_post` int(11) NOT NULL,
  `thumbup` int(11) NOT NULL,
  `file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `write_form`
--

INSERT INTO `write_form` (`idx`, `name`, `pw`, `title`, `content`, `date`, `hit`, `lock_post`, `thumbup`, `file`) VALUES
(1, 'dd', '$2y$10$ai.4REwhGGAPv6xloklDTeqsNWjDZ7YnziUBLAxzU561aYotXj9ES', 'dd', 'ddd', '2021-12-13', 0, 0, 0, ''),
(2, 'abca', '$2y$10$ZOWJeO1cwpzHDMXSFOZMJ.RibaWZpBBJisKvcsNz.i8ZKVpjEc.L6', 'gg', 'gg', '2021-12-14', 0, 0, 0, ''),
(4, 'abcd', '$2y$10$/eS9RFrDNe9xJHqU.Be3xOnmHurDixc8gWklMssvbVCFpvA2Mwn96', '안녕하세요', '안녕하세요. 가입인사 합니다 잘 부탁드려요~~', '2021-12-14', 0, 0, 0, ''),
(5, 'bbbb', '$2y$10$SwFtf28CDOK21YC8drg1E.ek86mvcmE5F5ZVDNLga3br/K4a23aXq', '안녕하세요', '안녕하세요. 가입인사 합니다 잘 부탁드려요~~', '2021-12-14', 0, 0, 0, ''),
(6, 'hhhh', '$2y$10$aCS0DyW2VcJ1zYYeriO7D.LGRkk7e.KWl0tQJyPQEzXeBKqaYT9Bq', '안녕하세요', '안녕하세요. 가입인사 합니다 잘 부탁드려요~~', '2021-12-14', 0, 0, 0, ''),
(7, 'qkd', '$2y$10$UmwVY6hjVqA4N6kKyipUVulEELuwkxCPdxtWIphKY8fzuipQjtIlu', '안녕하세요', '안녕하세요. 가입인사 합니다 잘 부탁드려요~~', '2021-12-14', 0, 0, 0, ''),
(8, 'qkd', '$2y$10$tx8lKXCckodNDJ2PzAS74emaUCR9D3WdNNLWjlkw7DZghFpUhwT3e', 'aa', 'aaa', '2021-12-14', 0, 0, 0, ''),
(9, 'anss', '$2y$10$wc5KuZaKGPfDPlN14lNdN.ji5pT7vjaItTCVRD8RDdXe6t/A/i0Ki', '안녕하세요', '안녕하세요. 가입인사 합니다 잘 부탁드려요~~', '2021-12-14', 0, 0, 0, ''),
(10, 'ghn', '$2y$10$.NZqXI9Y2nvZPcE3Fc19HuRobAQCq/T5RWBxzHqsKdSuaLMjwjWGW', '안녕하세요^^', '안녕하세요. 가입인사 합니다 잘 부탁드려요~~', '2021-12-14', 0, 0, 0, '');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `board2`
--
ALTER TABLE `board2`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `cre_board`
--
ALTER TABLE `cre_board`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `greet`
--
ALTER TABLE `greet`
  ADD PRIMARY KEY (`num`);

--
-- 테이블의 인덱스 `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`num`);

--
-- 테이블의 인덱스 `memo`
--
ALTER TABLE `memo`
  ADD PRIMARY KEY (`num`);

--
-- 테이블의 인덱스 `memo_ripple`
--
ALTER TABLE `memo_ripple`
  ADD PRIMARY KEY (`num`);

--
-- 테이블의 인덱스 `reply`
--
ALTER TABLE `reply`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `write_form`
--
ALTER TABLE `write_form`
  ADD PRIMARY KEY (`idx`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `board2`
--
ALTER TABLE `board2`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- 테이블의 AUTO_INCREMENT `cre_board`
--
ALTER TABLE `cre_board`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `greet`
--
ALTER TABLE `greet`
  MODIFY `num` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `members`
--
ALTER TABLE `members`
  MODIFY `num` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 테이블의 AUTO_INCREMENT `memo`
--
ALTER TABLE `memo`
  MODIFY `num` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- 테이블의 AUTO_INCREMENT `memo_ripple`
--
ALTER TABLE `memo_ripple`
  MODIFY `num` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `reply`
--
ALTER TABLE `reply`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 테이블의 AUTO_INCREMENT `write_form`
--
ALTER TABLE `write_form`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
