<?
$conn = mysqli_connect('localhost', 'root', '', 'project');
$board_number = 1;
echo "confirm file information <br/>";
$uploads_dir = "./uploads/$board_number";
$name = $_FILES['upload']['name'];
$uploadfile = $_FILES['upload']['name'];
?>
