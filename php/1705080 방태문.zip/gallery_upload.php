<?
$size = GetImageSize($image);
$width = $size[0];
$height = $size[1];
$imageblob = addslashes(fread(fopen($image, "r"), filesize($image)));
$filesize = filesize($image) ;

$query=" INSERT INTO gallery VALUES ('', '$imageblob', '$title', '$width','$height', '$filesize', '$detail' )" ;
$result=mysql_query($query,$connect );


- 이미지 리스트 보여주는 소스

$query= "select id, title, width, height from gallery order by id DESC " ;
$result=mysql_query($que1,$connect );
$row=mysql_fetch_array($result);
echo( "<table bordr=1 width=90% align=center>
<tr> <td>이미지</td>
<td>제목</td>
</tr>
");

while($row){
echo ( "<tr><td><img src=./view.html?id=$row[id]
width=$row[width] height=$row[height] ></td>
<td>$row[title]</td> ");
$row=mysql_fetch_array($result);
}
echo( "</table>");
}
?>
