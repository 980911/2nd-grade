$(document).ready(function(){
     //$("#home").load("ajax.html #aaa");
     $('.slider').bxSlider({
       auto: true,
        speed: 500,
        pause: 4000,
        mode:'fade',
        autoControls: true,
        pager:true,
        slidewidth: 170,
        captions: true
     });


   })
