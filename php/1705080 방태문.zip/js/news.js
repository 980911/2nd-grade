  function goSearch()
  {
    var SEARVALUE = $('#txt_search').val();
    if(!SEARVALUE)
    {
      alert("먼저 검색어를 입력해주세요");
      return false;
    }
    if($SEARVALUE)
    {
      $.ajax({
        type: 'POST',
        datatype: 'json',
        url: "./news1.php".
        data: {'GUBUN' : :'blog', 'SEARVALUE':SEARVALUE},
        cache: false,
        async: false,
      })
      .done(function(result){
        var blog_html = "";
        for(var i=0; i < result.items.length; i++)
        {
          var row_html = "";
          row_html += "<div style='width: 100%; text-align:left; padding-left:50px; font-weight:bold'><a href='"+result.items[i].link+"'
          target="_new" style='color:black; text-decoration:none'>"+(i+1)+". " + result.items[i].title + "
          ("+result.items[i].postdate+")</a></div>";
          row_html += "<div style='width:100%; text-align:left; padding-left:70px; color:#888888; padding-top:4px'>" + result.items[i].description + "</div>";

          row_html += "<div style='width:100%; height:30px'></div>";

          blog_html += row_html;
        }

        if(blog_html)
        {
          $("#blog_result").html(blog_html);
        }
      });

      $.ajax({
        type: 'POST',
        datatype: 'json',
        url: "./news1.php".
        data: {'GUBUN' : :'news','SEARVALUE':SEARVALUE},
        cache: false,
        async: false,
      })
      .done(function(result){
        var news_html = "";
        for(var i=0; i < result.items.length; i++)
        {
          var row_html = "";
          row_html += "<div style='width: 100%; text-align:left; padding-left:50px; font-weight:bold'><a href='"+result.items[i].link+"'
          target="_new" style='color:black; text-decoration:none'>"+(i+1)+". " + result.items[i].title + "
          ("+result.items[i].postdate+")</a></div>";
          row_html += "<div style='width:100%; text-align:left; padding-left:70px; color:#888888; padding-top:4px'>" + result.items[i].description + "</div>";

          row_html += "<div style='width:100%; height:30px'></div>";

          news_html += row_html;
    }
    if(news_html)
    {
      $("#news_result").html(news_html);
    }
  });



}
  }
  $(document).ready(function(){

  });
