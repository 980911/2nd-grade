<!DOCTYPE HTML>
<html>

<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="./css/common.css" media="all">
	<link rel="stylesheet" type="text/css" href="./css/memo.css" media="all">
</head>

<body>

	<div id="wrap">
		<div id="header">
			<?php include "./header.php"; ?>
		</div>
		<!-- end of header -->

		<div id="menu">
			<? include "./main.php"; ?>
		</div>
		<!-- end of menu -->

		<div id="content">
			<div id="col1">
				<div id="left_menu">
				</div>
			</div>
			<div id="col2" style="margin-left: 500px;">
				<div id="title">
          <h3>낙서장</h3>
				   </div>
					 <?php
					   if(isset($_SESSION["userid"])){

					 ?>
				<div id="memo_row1" style="display: inline-block;text-align: left;">
					<form name="memo_form" method="post" action="memo_insert.php">
						<div id="memo_writer"><span>이름: <?=$_SESSION["userid"]?></span></div>
						<div id="memo1"><textarea rows="6" cols="95" name="content"></textarea></div>
						<div id="memo2"><input type="image" src="./img/memo_button.gif"></div>
					</form>
				</div>
				<!-- end of memo_row1 -->
        <?php
			}
        	if (isset($_GET["page"]))
        		$page = $_GET["page"];
        	else
        		$page = 1;

        	$con = mysqli_connect("localhost", "root", "", "project");
        	$sql = "select * from memo order by num desc";
        	$result = mysqli_query($con, $sql);
        	$total_record = mysqli_num_rows($result); // 전체 글 수

        	$scale = 3;

        	// 전체 페이지 수($total_page) 계산
        	if ($total_record % $scale == 0)
        		$total_page = floor($total_record/$scale);
        	else
        		$total_page = floor($total_record/$scale) + 1;

        	// 표시할 페이지($page)에 따라 $start 계산
        	$start = ($page - 1) * $scale;

        	$number = $total_record - $start;

					for ($i=$start; $i<$start+$scale && $i < $total_record; $i++)
					{
						 mysqli_data_seek($result, $i);
						 // 가져올 레코드로 위치(포인터) 이동
						 $row = mysqli_fetch_array($result);
						 // 하나의 레코드 가져오기

						$memo_id      = $row["id"];
	 				  $num         = $row["num"];
	 					$memo_date    = $row["regist_day"];
	 					$memo_nick    = $row["nick"];

						$memo_content = str_replace("\n", "<br>", $row["content"]);
						$memo_content = str_replace(" ", "&nbsp;", $memo_content);
					?>

					<div id="memo_writer_title">
	 				<ul>
		 				<li id="writer_title1">
			 			<?= $number ?>
		 		</li>
		 				<li id="writer_title2">
			 		<?=$_SESSION["userid"]?>
		 			</li>
		 			<li id="writer_title3">
			 		<?= $memo_date ?>
		 			</li>
		 			<li id="writer_title4">
			 			<?
 					if($userid=="admin" || $userid==$memo_id)<br>
			  echo"<a href='delete.php?num=$<?=$num?>'>[삭제]</a>";
?>
		 </li>
	 </ul>
 </div>
 <div id="memo_content">
        <?= $memo_content ?>
      </div>
      <div id="ripple">
        <div id="ripple1">덧글</div>
        <div id="ripple2">
          <?
  $sql = "select * from memo_ripple where parent='$memo_num'";
  $ripple_result = mysql_query($sql);

while ($row_ripple = mysql_fetch_array($ripple_result))
{
  $ripple_num     = $row_ripple["num"];
  $ripple_id      = $row_ripple["id"];
  $ripple_nick    = $row_ripple["nick"];


?>
            <div id="ripple_title">
              <ul>
                <li>
                </li>
                <li id="mdi_del">
                  <?php
									if(isset($_SESSION["userid"])){
										if($userid=="admin")
						         echo "<a href='delete_ripple.php?num=$ripple_num'>삭제</a>";
									}
      ?>
                </li>
              </ul>
            </div>
            <div id="ripple_content">

            </div>
            <?php
}
if(isset($_SESSION["userid"])){
?>
<form name="ripple_form" method="post" action="insert_ripple.php">
		<input type="hidden" name="num" value="<?= $memo_num ?>">
		<div id="ripple_insert">
			<div id="ripple_textarea">
				<textarea rows="3" cols="80" name="ripple_content"></textarea>
			</div>
			<div id="ripple_button"><input type="image" src="./img/memo_ripple_button.png"></div>
		</div>
	</form>

</div>
<!-- end of ripple2 -->
<div class="clear"></div>
<div class="linespace_10"></div>
					<?php
							$number--;
					}
					mysqli_close($con);

					?>
					</ul>
						 <ul id="page_num">

		 							<div id="page_num"> ◀ 이전 &nbsp;&nbsp;&nbsp;&nbsp;
		 								<?php
		    // 게시판 목록 하단에 페이지 링크 번호 출력
		    for ($i=1; $i<=$total_page; $i++)
		    {
		 		if ($page == $i)     // 현재 페이지 번호 링크 안함
		 		{
		 			echo "<b> $i </b>";
		 		}
		 		else
		 		{
		 			echo "<a href='memo.php?page=$i'> $i </a>";
		 		}
		    }

		 ?>
		 									&nbsp;&nbsp;&nbsp;&nbsp;다음 ▶</div>
		 					</div>
		 					<!-- end of ripple -->
		 			</div>
		 			<!-- end of col2 -->
		 		</div>
		 		<!-- end of content -->
		 	</div>
		 	<!-- end of wrap -->

</body>

</html>
