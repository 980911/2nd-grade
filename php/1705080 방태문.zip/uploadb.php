<?php

session_start();

if($_SESSION['idno'] == '') exit;

$s_idno = $_SESSION['idno'];



$sql = "select * from photo where idno='$s_idno'";

$row = dbqueryfetch($sql);



header("Content-type: image/jpeg");

echo $row['image'];

exit;

?>
