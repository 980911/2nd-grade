<?php
	include  $_SERVER['DOCUMENT_ROOT']."./project2/db.php";

	$bno = $_GET['idx'];
	$sql = query("delete from board2 where idx='$bno';");
?>
<script type="text/javascript">alert("삭제되었습니다.");</script>
<meta http-equiv="refresh" content="0 url=./index.php" />
