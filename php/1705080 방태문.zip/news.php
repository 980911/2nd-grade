<link href="./css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="./css/greet.css" rel="stylesheet" type="text/css" media="all">
<?php include "header.php";?>

<?php
	if (!$userid )
	{
		echo("<script>
				alert('로그인 후 이용해주세요!');
				history.go(-1);
				</script>
			");
		exit;
	}
?>
<?php
  ini_set("allow_url_fopen", 1);
  $url ="https://search.naver.com/search.naver?where=news&query=%EC%9E%90%EC%A0%84%EA%B1%B0&sm=tab_tmr&nso=so:r,p:all,a:all&sort=0";
  echo "<li><a href='https://search.naver.com/search.naver?query=%EC%9E%90%EC%A0%84%EA%B1%B0&where=news&ie=utf8&sm=nws_hty'>뉴스 더보기</a> <li>";
  include "simple_html_dom.php";

  $data = file_get_html($url);

  foreach($data->find("div.api_subject_bx") as $li){
    echo $li;
  }
?>
