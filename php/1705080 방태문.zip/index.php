<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>자전거 동호회</title>
<link rel="stylesheet" type="text/css" href="./css/common.css">
<link rel="stylesheet" type="text/css" href="./css/main.css">
  <script type="text/javascript" src="./js/slideshow.js"></script>
</head>
<body>
	<header>
    	<?php include "header.php";?>
    </header>
	<section>
	    <?php include "main.php";?>
	</section>
	  <?include $_SERVER['DOCUMENT_ROOT']."./board1.php";?>
</body>
</html>
