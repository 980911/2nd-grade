<?session_start()?>
<?
  if(!isset($_SESSION["userid"]))

?>
<?php
    $id=$_SESSION["id"];
    $content=$_POST["content"];
    $num=$_POST["num"];

    $con = mysqli_connect("localhost", "root", "", "project");
    $sql = "insert into memo (id, content, regist_day)";
    $sql .= "values('$id', '$content', now())";
     mysqli_query($con, $sql);  // $sql 에 저장된 명령 실행


     mysqli_close($con);


     echo "
   	   <script>
   	    location.href = 'memo.php';
   	   </script>
   	";
?>
