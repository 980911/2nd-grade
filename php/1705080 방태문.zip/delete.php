<?
    $num  = $_GET["num"];
    $page   = $_GET["page"];

    $con = mysqli_connect("localhost", "root", "", "project");
    $sql = "select * from board where memo num = $num";

    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($result);


    $sql = "delete from memo where memo num = $num";
    $result = mysql_query($sql, $con);
	  $row = mysqli_fetch_array($result);
    mysqli_query($con, $sql);
    mysqli_close($con);


   echo "
      <script>
          location.href = 'memo.php';
      </script>
    ";

?>
