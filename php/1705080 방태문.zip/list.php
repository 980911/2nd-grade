<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>자유게시판</title>
<link href="./css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="./css/greet.css" rel="stylesheet" type="text/css" media="all">
</head>
<body>
<header>
    <?php include "header.php";?>
</header>
<section>
  <div id="main_img" style="margin-left:500px">
        <img src="./img/main.jpg"  width="900px";>

    </div>
   	<div id="board_box">
	    <h3>
	    	게시판 > 목록보기
		</h3>
	    <ul id="board_list">
				<li>
					<span class="col1">번호</span>
					<span class="col2">제목</span>
					<span class="col3">글쓴이</span>
					<span class="col4">첨부</span>
					<span class="col5">등록일</span>
					<span class="col6">조회</span>
				</li>
<?
	$userid = $_SESSION['userid'];
	$mode = $_GET['mode'];
	$find = $_POST['find'];
	$search = $_POST['search'];

	if (isset($_GET["page"]))
		$page = $_GET["page"];
	else
		$page = 1;

	$con = mysqli_connect("localhost", "root", "", "project");
	$sql = "select * from greet order by num desc";
	$result = mysqli_query($con, $sql);
	$total_record = mysqli_num_rows($result); // 전체 글 수


	$scale = 10;
	if ($mode=="search")
{
	if(!$search)
	{
		echo("
			<script>
			 window.alert('검색할 단어를 입력해 주세요!');
				 history.go(-1);
			</script>
		");
		exit;
	}

	$sql = "select * from greet where $find like '%$search%' order by num desc";
}
else
{
	$sql = "select * from greet order by num desc";
}

$result = mysql_query($sql, $connect);

$total_record = mysql_num_rows($result); // 전체 글 수
	// 전체 페이지 수($total_page) 계산
	if ($total_record % $scale == 0)
		$total_page = floor($total_record/$scale);
	else
		$total_page = floor($total_record/$scale) + 1;

		if (!$page)                 // 페이지번호($page)가 0 일 때
				$page = 1;              // 페이지 번호를 1로 초기화

			// 표시할 페이지($page)에 따라 $start 계산
			$start = ($page - 1) * $scale;

			$number = $total_record - $start;
		?>


				<li>

					<span class="col1"><?=$number?></span>
					<span class="col2"><a href="view.php?num=<?=$num?>&page=<?=$page?>"><?=$subject?></a></span>
					<span class="col3"><?=$name?></span>
					<span class="col4"><?=$file_image?></span>
					<span class="col5"><?=$regist_day?></span>
					<span class="col6"><?=$hit?></span>

				</li>
<?
   	   $number--;
   }
   mysqli_close($con);

?>
</ul>  <div id="list_search1" style="margin-left:260px;">▷ 총 <?= $total_record ?> 개의 게시물이 있습니다.  </div>
			<ul id="page_num">
<?php
	if ($total_page>=2 && $page >= 2)
	{
		$new_page = $page-1;
		echo "<li><a href='view.php?page=$new_page'>◀ 이전</a> </li>";
	}
	else
		echo "<li>&nbsp;</li>";

   	// 게시판 목록 하단에 페이지 링크 번호 출력
   	for ($i=1; $i<=$total_page; $i++)
   	{
		if ($page == $i)     // 현재 페이지 번호 링크 안함
		{
			echo "<li><b> $i </b></li>";
		}
		else
		{
			echo "<li><a href='view.php?page=$i'> $i </a><li>";
		}
   	}
   	if ($total_page>=2 && $page != $total_page)
   	{
		$new_page = $page+1;
		echo "<li> <a href='view.php?page=$new_page'>다음 ▶</a> </li>";
	}
	else
		echo "<li>&nbsp;</li>";
?>
			</ul> <!-- page -->

			<ul class="buttons">
				<li><button onclick="location.href='list.php'">목록</button></li>

				<li>
<?php
    if($userid) {
?>
					<button onclick="location.href='view.php'">글쓰기</button>
<?php
	} else {
?>
					<a href="javascript:alert('로그인 후 이용해 주세요!')"><button>글쓰기</button></a>
<?php
	}
?>
				</li>
			</ul>
	</div> <!-- board_box -->
</section>

</body>
</html>
