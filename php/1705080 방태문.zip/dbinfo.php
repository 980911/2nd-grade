<?php
$db['host'] = "localhost";
$db['name'] = "project";
$db['user'] = "root";
$db['pass'] = "";
$db['port'] = "3306";
?>
